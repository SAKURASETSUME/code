#ifndef __TIMER_H
#define __TIMER_H

#include "stm32f10x.h"                  // Device header
#include "delay.h"

void Timer_Init(void);
void TIM2_IRQHandler(void);

#endif

