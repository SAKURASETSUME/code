#ifndef __KEY_H
#define __KEY_H

#include "stm32f10x.h"                  // Device header
#include "delay.h"

void ExtiKey_Init(void); //������ʼ��
uint16_t ExtiKey_Get(void);
void EXTI15_10_IRQHandler(void);

#endif

